# Release 0.2.10

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes
1. 更新sdk版本。
2. 时间戳修改。
## Submodule Versions
1. deptrum-stream aurora900 sdk version 1.1.19
2. jpeg turbo version 2.1.0

# Release 0.2.9

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes
1. Create stream修改。
## Submodule Versions
1. deptrum-stream aurora900 sdk version 1.1.3
2. jpeg turbo version 2.1.0
3. 
# Release 0.2.8

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes
1. 心跳默认关闭。
## Submodule Versions
1. deptrum-stream aurora900 sdk version 1.1.3
2. jpeg turbo version 2.1.0

# Release 0.2.5

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes
1. 多设备坐标区分。

## Submodule Versions
1. deptrum-stream aurora900 sdk version 1.1.3
2. jpeg turbo version 2.1.0

# Release 0.2.4

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes
1. 心跳功能增加。
2. 升级功能增加。

## Submodule Versions
1. deptrum-stream aurora900 sdk version 1.1.4
2. jpeg turbo version 2.1.0

# Release 0.2.3

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes
1. 完善枚举问题。

## Submodule Versions
1. deptrum-stream aurora900 sdk version 1.1.4
2. jpeg turbo version 2.1.0

# Release 0.2.2

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 新版本stream适配，GetFrame, CreateStream等。
2. 心跳功能增加。

## Submodule Versions

1. deptrum-stream aurora900 sdk version 1.1.3
2. jpeg turbo version 2.1.0

# Release 0.2.1

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 增加rgbdpointcloud流，只保留 rgb depth 分辨率相同的分辨率类型。

## Submodule Versions

1. deptrum-stream aurora900 sdk version 1.0.54
2. jpeg turbo version 2.1.0

# Release 0.1.4

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 新增订阅节点发布打包
2. 添加单元测试脚本

## Submodule Versions

1. deptrum-stream aurora900 sdk version 1.0.50
2. jpeg turbo version 2.1.0


# Release 0.1.3

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. aurora932支持，同步更新ros1 930/932提测bug

## Submodule Versions

1. deptrum-stream aurora900 sdk version 1.0.50
2. jpeg turbo version 2.1.0

# Release 0.1.2

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 修改时间戳问题

## Submodule Versions

1. deptrum-stream aurora900 sdk version 1.0.47
2. jpeg turbo version 2.1.0

# Release 0.1.1

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 将各设备安装到各个包名下，方便一台机器安装多个ros设备包

## Submodule Versions

1. deptrum-stream aurora900 sdk version 1.0.47
2. jpeg turbo version 2.1.0

# Release 0.0.4

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 更新aurora900版本 1.0.47

## Submodule Versions

1. deptrum-stream aurora900 sdk version 1.0.47
2. jpeg turbo version 2.1.0

# Release 0.0.3

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 解决二轮提测bug

## Submodule Versions

1. deptrum-stream aurora900 sdk version 1.0.40
2. jpeg turbo version 2.1.0

# Release 0.0.2

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 修改提测bug

## Submodule Versions

1. deptrum-stream aurora900 sdk version 1.0.40
2. jpeg turbo version 2.1.0

# Release 0.0.1

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. ros2代码提测

## Submodule Versions

1. deptrum-stream aurora900 sdk version 1.0.40
2. jpeg turbo version 2.1.0