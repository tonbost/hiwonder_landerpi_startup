# Release 0.1.4

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 新版本stream适配，GetFrame, CreateStream等。
## Submodule Versions

1. deptrum-stream stellar400 sdk version 1.1.2
2. jpeg turbo version 2.1.0

# Release 0.1.3

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 新增订阅节点打包
2. 添加单元测试脚本
## Submodule Versions

1. deptrum-stream stellar400 sdk version 1.0.57
2. jpeg turbo version 2.1.0

# Release 0.1.2

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 修改时间戳问题
## Submodule Versions

1. deptrum-stream stellar400 sdk version 1.0.57
2. jpeg turbo version 2.1.0

# Release 0.1.1

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 将各设备安装到各个包名下，方便一台机器安装多个ros设备包

## Submodule Versions

1. deptrum-stream stellar400 sdk version 1.0.57
2. jpeg turbo version 2.1.0

# Release 0.0.3

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 增加版本信息发布

## Submodule Versions

1. deptrum-stream stellar400 sdk version 1.0.57
2. jpeg turbo version 2.1.0

# Release 0.0.1

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. ros2代码提测


## Submodule Versions

1. deptrum-stream stellar400 sdk version 1.0.51
2. jpeg turbo version 2.1.0