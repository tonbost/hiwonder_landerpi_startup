#!/bin/bash -e

sudo apt-get install libusb-1.0-0-dev
sudo apt-get install libgl1-mesa-dev
sudo apt-get install build-dep glfw
sudo apt-get install libglu1-mesa-dev
sudo apt-get install libxi-dev
sudo apt-get install libudev-dev
