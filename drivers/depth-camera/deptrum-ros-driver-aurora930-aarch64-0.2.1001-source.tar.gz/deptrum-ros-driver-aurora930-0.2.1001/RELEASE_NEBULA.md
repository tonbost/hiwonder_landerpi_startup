# Release 0.2.10

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. stream create修改。
## Submodule Versions
1. deptrum-stream nebula sdk version v1.2.14

# Release 0.2.9

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 增加 rd/rmd topic。
## Submodule Versions
1. deptrum-stream nebula sdk version v1.2.12

# Release 0.2.8

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. stream sdk1.2.12 增加nebula imu输出。
## Submodule Versions
1. deptrum-stream nebula sdk version v1.2.12

# Release 0.2.7

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. stream sdk1.2.9, nebula 扩展rgb支持。
## Submodule Versions
1. deptrum-stream nebula sdk version v1.2.9

# Release 0.2.6

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. stream sdk1.2.5, 适配新版本点云流程等。
## Submodule Versions
1. deptrum-stream nebula sdk version v1.2.5

# Release 0.2.5

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. stream sdk1.1.56, 支持nebula400。
## Submodule Versions
1. deptrum-stream nebula 200 sdk version v1.1.56

# Release 0.2.4

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 适配mode14 模组，裁切等。
## Submodule Versions
1. deptrum-stream nebula 200 sdk version v1.1.48

# Release 0.2.1

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1.增加mtof 裁切范围。
## Submodule Versions
1. deptrum-stream nebula 200 sdk version v1.1.40

# Release 0.2.0

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1.解决rgb无法显示的问题
2.更新stream-sdk版本
## Submodule Versions
1. deptrum-stream nebula 200 sdk version v1.1.37

# Release 0.1.9

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1.增加获取SerialNumber节点
2.完善nebula 200的文档
3.删除nebula 200的launch文件中无用的参数
4.更新stream-sdk版本
## Submodule Versions
1. deptrum-stream nebula 200 sdk version v1.1.35
# Release 0.1.8

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 新版本stream适配，GetFrame, CreateStream等。
## Submodule Versions

1. deptrum-stream nebula 200 sdk version v1.1.14
2. jpeg turbo version 2.1.0

# Release 0.1.7

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 修复内存泄漏
## Submodule Versions

1. deptrum-stream nebula 200 sdk version v1.1.4
2. jpeg turbo version 2.1.0


# Release 0.1.6

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 新增了SetMtofAeMode/GetMtofAeMode接口，只有在双mtof时可以生效，模组默认是20fps 的mtof ae模式
2. 新增ir对齐到rgb分辨率。修复debug模式下点云的崩溃问题。兼容双mtofae 模式下的点云显示问题
3. 新增ChangeFilterLevel接口

## Submodule Versions

1. deptrum-stream nebula 200 sdk version v1.1.2_nebula220_0106 
2. jpeg turbo version 2.1.0

# Release 0.1.5

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 适配nebula220
2. 更新220 sdk版本

## Submodule Versions

1. deptrum-stream nebula 200 sdk version v1.1.1_nebula220_1121
2. jpeg turbo version 2.1.0

# Release 0.1.4

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 新增订阅节点打包
2. 增加rgbd流输出
3. 添加单元测试脚本


## Submodule Versions

1. deptrum-stream nebula 200 sdk version v1.0.14
2. jpeg turbo version 2.1.0

# Release 0.1.3

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 增加rgbd有彩点云配置


## Submodule Versions

1. deptrum-stream nebula 200 sdk version v1.0.13
2. jpeg turbo version 2.1.0

# Release 0.1.2

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 增加设置stof最小距离接口


## Submodule Versions

1. deptrum-stream nebula 200 sdk version v1.0.6
2. jpeg turbo version 2.1.0

# Release 0.1.1

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. 将各设备安装到各个包名下，方便一台机器安装多个ros设备包


## Submodule Versions

1. deptrum-stream nebula 200 sdk version v1.0.9
2. jpeg turbo version 2.1.0

# Release 0.0.1

## Major Features and Improvements

## Breaking Changes

## Bug Fixes and Other Changes

1. nebula代码提交


## Submodule Versions

1. deptrum-stream nebula 200 sdk version v1.0.0_nebula_v18
2. jpeg turbo version 2.1.0
